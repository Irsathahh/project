## FindingHospitals
finding hospitals is a project which automates testing in the websites to
1. print all hospitals with rating > 3.5, open 24*7 and has parking.
2. print all the top cities.
3. enter valid and invalid details in the corporate wellness page and check "Schedule a demo" is enabled or not.

## website
the website used in this project is
    "https://www.practo.com/"

## Tools and Plugins used
1. Selenium with Java
2. Maven
3. TestNG
4. POM
5. Extent reports

## Changes in website
1)Initally the requirement was to fill valid and invalid details in corporate wellness page and capture the alerts.
Now since the webpage is updated and the alerts are removed we had to impovise and test the enablement of "Schedule a demo" button.
The project focuses on testing the enablement of the button by entering valid and invalid value in respective fields.

2)The Filteration method is based on deliveriables but due to update. 
The link will show only hospital name according to cities not with deliveriable filters(24x7 && Parking).  
