package hackathon;

import java.util.Properties;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class InvokeBrower {
	public static Properties prop;
	public static WebDriver driver;
	ExtentHtmlReporter htmlReporter;
	ExtentReports extent;
	ExtentTest test;

// For using ExtentReport
	@BeforeSuite
	public void extentReport() {
		// start reporters
		htmlReporter = new ExtentHtmlReporter("extent.html");

		// create ExtentReports and attach reporter(s)
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);

	}

	// Driver setup by user
	@BeforeTest
	public void driverSetUp() throws Exception {
		Scanner sc = new Scanner(System.in);
		System.out.println("Choose a valid browser \n 1)Chrome \n 2)FireFox \n 3)MicrosoftEDGE");
		int browserselect = sc.nextInt();
		sc.close();
		prop = new Properties();
		try {
			// For ChromeDriver
			if (browserselect == 1) {
				System.setProperty("webdriver.chrome.driver",
						"C:\\Users\\2252171\\OneDrive - Cognizant\\Desktop\\chromedriver.exe");
				driver = new ChromeDriver();
				System.out.println("Chrome launched");
			}
			// For FireFoxDriver
			else if (browserselect == 2) {
				System.setProperty("webdriver.gecko.driver",
						"C:\\Users\\2252171\\OneDrive - Cognizant\\Desktop\\geckodriver.exe");
				driver = new FirefoxDriver();
				System.out.println("FireFox launched");
			}
			// For Edge Driver
			else if (browserselect == 3) {
				System.setProperty("webdriver.edge.driver",
						"C:\\Users\\2252171\\OneDrive - Cognizant\\Desktop\\msedgedriver.exe");
				driver = new EdgeDriver();
				System.out.println(" EDGE launched");
			} else {
				System.out.println("Please choose valid browser");
			}
			// To maximize the window
			driver.manage().window().maximize();

			driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
			test = extent.createTest("Practo Test", "User Browser is launched");

		} catch (Exception e1) {
			e1.printStackTrace();
		}
		test.pass("Browser Launched");
	}

	// Close the browser after Use
	@AfterTest
	public void closeBrowser() {
		driver.quit();
		test.pass("Browser Closed");
	}

	@AfterSuite
	public void reportGenerate() {
		extent.flush();
	}

}