package hackathon;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class CorporateWellness extends Diagnostic_page {
	String actual = "https://www.practo.com/plus/corporate?submitted=true";
	String current;

	@Test(priority = 5)
	public void corporateWelness() throws InterruptedException {
		driver.navigate().back(); // Navigating to HomePage
		String CHandle = driver.getWindowHandle();
		if (CHandle.matches(Home_page)) {
			test.pass("Navigate Homepage");
		} else {
			test.fail("Not Navigated Properly");
		}
		WebElement wellness = driver.findElement(By.xpath("/html/body/div/div/div/div[1]/div[1]/div[2]/div/div[3]/div[1]/span/span[3]"));
		wellness.click();
		
		Actions actions = new Actions(driver);
		WebElement wel = driver.findElement(By.xpath("//*[@id='root']/div/div/div[1]/div[1]/div[2]/div/div[3]/div[1]/span/div/div[1]/a"));
		actions.moveToElement(wel);
		actions.click().perform();
		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		// Copy the file to a location and use try catch block to handle exception
		try {

			FileUtils.copyFile(screenshot, new File(
					"C:\\Users\\2252171\\OneDrive - Cognizant\\Pictures\\Screenshots\\Hackathon_Snaps\\pic1.png"));
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		WebElement k = driver.findElement(By.id("name"));
		k.sendKeys("ManoKaran");
		
		WebElement oname = driver.findElement(By.id("organizationName"));
		oname.sendKeys("KS Hospitals");
		
		WebElement mbl = driver.findElement(By.id("contactNumber"));
		mbl.sendKeys("9944032334");
		
		WebElement emailid = driver.findElement(By.id("officialEmailId"));
		emailid.sendKeys("kshotpitals@gmail.com");

		WebElement size = driver.findElement(By.id("organizationSize"));
		Select sc = new Select(size);
		sc.selectByValue("5001-10000");

		WebElement interest = driver.findElement(By.id("interestedIn"));
		Select k1 = new Select(interest);
		k1.selectByValue("Referring someone");
		File screenshot1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		// Copy the file to a location and use try catch block to handle exception
		try {

			FileUtils.copyFile(screenshot1, new File(
					"C:\\Users\\2252171\\OneDrive - Cognizant\\Pictures\\Screenshots\\Hackathon_Snaps\\pic2.png"));
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		WebElement submit = driver.findElement(By.cssSelector("#header > div.form-container > div > form > button"));
		Actions actions1 = new Actions(driver);
		actions1.moveToElement(submit).click().perform();
		Thread.sleep(2000);
		// Take the screenshot
		File screenshot11 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		current = driver.getCurrentUrl();
		if (actual.equals(current)) {
			test.pass("corporate Wellness is passed");
			
		} else if(actual.equals("https://www.practo.com/plus/corporate")){
			test.info("corporate Wellness is failed due to Captcha");
		}else {
			test.fail("corporate Wellness is failed");
		}
		// Copy the file to a location and use try catch block to handle exception
		try {

			FileUtils.copyFile(screenshot11, new File(
					"C:\\Users\\2252171\\OneDrive - Cognizant\\Pictures\\Screenshots\\Hackathon_Snaps\\pic3.png"));
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

}
