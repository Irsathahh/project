package hackathon;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class Diagnostic_page extends Practo {
	@Test(priority = 4)
	public void selectDiagnostic() throws IOException {
		List<WebElement> listOfElement;
		
		try {
			driver.navigate().back(); // Navigating to home page
			String current_Handle = driver.getWindowHandle();
			if (current_Handle.matches(Home_page)) {
				test.pass("Navigate Homepage");
			} else {
				test.fail("Not Navigated Properly");
			}

			// To Scroll Down
			JavascriptExecutor js = (JavascriptExecutor) driver;
			Thread.sleep(3000);

			js.executeScript("window.scroll(0,3000)");
			driver.findElement(By.xpath("/html/body/div[1]/div/div/footer/div/div[1]/div[2]/div[2]/a[4]/span")).click();

			// To store topCities name in a list
			listOfElement = driver.findElements(By.xpath("/html/body/div[3]/div/div/div/div/div/div/div/div[3]/ul"));
			
			for (WebElement eachcity : listOfElement) {
				System.out.println("\n**************************  Top Cities Are   **************************\n");
				System.out.println(eachcity.getText());
			}
			int y = listOfElement.size();
			if (y == 1) {
				test.pass("Top Cites are Got");
			} else {
				test.fail("TopCites Shows Mistakes");
			}
			driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("*************************************************************************************");
		File Diagnos = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(Diagnos, new File("C:\\Users\\2252171\\OneDrive - Cognizant\\Pictures\\Screenshots\\Hackathon_Snaps\\Diagnostic.png"));
		
	}
}
