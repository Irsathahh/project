package hackathon;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class Practo extends InvokeBrower {
	List<WebElement> names;
	List<WebElement> rating;
	
	By Location = By.xpath("//input[@placeholder='Search location']");
	By Xmark = By.xpath("//*[@class='icon-ic_cross_solid']");
	String Home_page;

	// get the URL
	@Test(priority = 0)
	public void getURL() {
		try {
			prop.load(new FileInputStream(
					"C:\\Users\\2252171\\OneDrive - Cognizant\\Desktop\\imaven\\hackathon\\src\\main\\java\\Config\\config.properties"));
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

		driver.get(prop.getProperty("WebsiteURL"));
		Home_page = driver.getWindowHandle();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		test.pass("URL is Launched in Website");

	}

//Choose the city "Bangalore" and type "Hospital"
	@Test(priority = 1)
	public void selectCity() throws InterruptedException {

		driver.findElement(Location).click();
		driver.findElement(Xmark).click();
		driver.findElement(Location).sendKeys("Bangalor".trim());
		Thread.sleep(2000);
		test.pass("Bangalore Selected");
	}

//Give"Hospital" in  search
	@Test(priority = 2)
	public void useHospital() throws Exception {
		By hospitalFinding = By.xpath("//*[@id='c-omni-container']/div/div[1]/div[2]/div[2]/div[1]/span[1]/div");
		driver.findElement(hospitalFinding).click();
		driver.findElement(By.xpath("//*[@placeholder='Search doctors, clinics, hospitals, etc.']"))
				.sendKeys("Hospital".trim());
		Thread.sleep(1500);
		driver.findElement(By.xpath("//*[@id='c-omni-container']/div/div[2]/div[2]/div[1]/div[2]")).click();
		test.pass("Hospital Selected");
	}

	@Test(priority = 3)
	public void getHospitalNames() throws InterruptedException, IOException {
		try {
			System.out.println("*****Hospital Names*****\n");
			File hosp = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(hosp, new File("C:\\Users\\2252171\\OneDrive - Cognizant\\Pictures\\Screenshots\\Hackathon_Snaps\\Bangalorehospitals.png"));
			
			// To scroll down
			JavascriptExecutor j = (JavascriptExecutor) driver;
			Thread.sleep(500);
			j.executeScript("window.scroll(0,3000)");
			rating = driver.findElements(By.xpath("//div[contains(@class,'c-estb-card')]/div[3]/div/div/span[1]"));
			names = driver.findElements(By.xpath("//div[contains(@class,'c-estb-info')]/a"));
			for (int i = 0; i < rating.size(); i++) {
				float rate = Float.parseFloat(rating.get(i).getText());
				if (rate > 3.5) {
					System.out.println("Rating:" + rating.get(i).getText() + " -> " + names.get(i).getText());
				}
			}
			String a = names.get(0).getText();
			if (a.matches("BGS Gleneagles Global Hospital")) {
				test.pass("The Report for Bangalore");
			} else {
				test.fail("The Report is not for Bangalore");
			}
		} catch (Exception e) {
			e.getMessage();
		}

	}
}
