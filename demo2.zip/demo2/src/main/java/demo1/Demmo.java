package demo1;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Demmo {
	public static WebDriver driver;
	TakesScreenshot takescreen;
	File sourcefile;
	String path;
	String filteroption = "Price (high to low)";
	By username = By.id("user-name");
	By password = By.id("password");
	By Login_Button = By.id("login-button");
	By Dropdown = By.xpath("//*[@id='header_container']/div[2]/div/span/select");
	By Addtocart_button = By.id("add-to-cart-sauce-labs-fleece-jacket");
	By Cart = By.xpath("//*[@id='shopping_cart_container']/a");
	By checkout = By.id("checkout");
	By detail_f = By.id("first-name");
	By detail_s = By.id("last-name");
	By code = By.id("postal-code");
	By continueB = By.id("continue");
	By finishc = By.id("finish");
	By backproduct = By.id("back-to-products");
	By navigate = By.id("react-burger-menu-btn");
	By logout = By.id("logout_sidebar_link");
	public static WebDriverWait wait;
	public static Properties prop = new Properties();

	// screenshot
	public void screenshot(String filename) {
		takescreen = (TakesScreenshot) driver;
		sourcefile = takescreen.getScreenshotAs(OutputType.FILE);
		path = System.getProperty("user.dir") + "\\screenshot\\" + filename + ".png";
		try {
			FileUtils.copyFile(sourcefile, new File(path));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// setup a browser
	public void browser() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\2252171\\OneDrive - Cognizant\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.get("https://www.saucedemo.com/");
	}
	// Declaring the wait function for all use
		public void wait(int num, By locator) {
			wait = new WebDriverWait(driver, num);
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		}
	// Login credentials
	public void login_setup(String username1, String password1) throws IOException {
		driver.findElement(username).sendKeys(username1);
		driver.findElement(password).sendKeys(password1);
		driver.findElement(Login_Button).click();
		wait(2000,Dropdown);
	}

	// add to cart
	public void addtocart() {
		WebElement drop = driver.findElement(Dropdown);
		Select solutions = new Select(drop);
		solutions.selectByVisibleText(filteroption);
		wait(1000,Addtocart_button);
		driver.findElement(Addtocart_button).click();
		driver.findElement(Cart).click();
		wait(2000,checkout);
	}

	// inside process
	public void details(String fname, String lname, String codes) throws IOException {
		driver.findElement(checkout).click();
		driver.findElement(detail_f).sendKeys(fname);
		driver.findElement(detail_s).sendKeys(lname);
		driver.findElement(code).sendKeys(codes);
		driver.findElement(continueB).click();
		driver.findElement(finishc).click();
		screenshot("Screenshot1");
	}

	// Final validation
	public void completef() {
		WebElement complete = driver.findElement(By.xpath("//*[@id='header_container']/div[2]/span"));
		String comple1 = complete.getText();
		System.out.println(comple1);
		String comple2 = "Checkout: Complete!";
		if (comple1 == comple2) {
			System.out.println("Validation Correct");
		}
		driver.findElement(backproduct).click();
		driver.findElement(navigate).click();
		driver.findElement(logout).click();
		driver.close();
	}

	public static void main(String[] args) throws IOException {
		Demmo d = new Demmo();
		prop.load(new FileInputStream(System.getProperty("user.dir") + "\\config\\config.properties"));
		d.browser();
		d.login_setup(prop.getProperty("username"), prop.getProperty("password"));
		d.addtocart();
		d.details(prop.getProperty("fname"), prop.getProperty("lname"), prop.getProperty("codes"));
		d.completef();
	}
}
